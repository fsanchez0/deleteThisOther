<?php
include '../general/sessionclase.php';
include_once('../general/conexion.php');
include '../general/funcionesformato.php';

//Modulo

$id=@$_GET["contrato"];



$misesion = new sessiones;
if($misesion->verifica_sesion()=="yes")
{
/*
	//Verifica los privilegios de este modulo
	$sql="select * from submodulo where archivo ='privilegios.php'";
	$operacion = mysql_query($sql);
	while($row = mysql_fetch_array($operacion))
	{

		$priv = $misesion->privilegios_secion($row['idsubmodulo']);
		$priv=split("\*",$priv);

	}
*/
$html = <<<cavecera
<html>
<head>
	<title>Grupo Bujalil S.C.</title>
<head>
<link rel="stylesheet" type="text/css" href="../estilos/estilos.css">
</HEAD>
<BODY>
cavecera;


	$hoy=date('Y') . "-" . date('m') . "-" . date('d');
	$sql= "SELECT contrato.idcontrato as elidcontrato, inquilino.nombre, inquilino.nombre2, inquilino.apaterno, inquilino.amaterno, inquilino.tel as inqtel,tipocobro, fechagenerado , historia.fechanaturalpago, historia.cantidad, aplicado, historia.interes, historia.iva as ivah, fiador.nombre as fnombre, fiador.nombre2 as fnombre2, fiador.apaterno as fapaterno, fiador.amaterno as famaterno, fiador.direccion as fdireccion, fiador.tel as ftel, calle, numeroext, numeroint, colonia, delmun, estado, pais, cp, inmueble.tel as itel FROM contrato, cobros, inquilino,tipocobro, historia, fiador, inmueble WHERE cobros.idtipocobro=tipocobro.idtipocobro and contrato.idcontrato=historia.idcontrato and historia.idcobros=cobros.idcobros and contrato.idinquilino=inquilino.idinquilino and historia.aplicado=false and contrato.idfiador=fiador.idfiador and contrato.idinmueble = inmueble.idinmueble and historia.fechanaturalpago <= '$hoy' and contrato.idcontrato = $id order by inquilino.idinquilino, fechanaturalpago, historia.idhistoria";
	$html .= "<h1>Pendientes por cobrar</h1>\n";

	$operacion = mysql_query($sql);
	$ccontrato=0;
	$grentas=0;
	$gotros=0;
	$ginteres=0;
	$rentas=0;
	$otros=0;
	$interes=0;
	$html .= "<table border=\"0\">";
	while($row = mysql_fetch_array($operacion))
	{

		if($ccontrato!=$row["elidcontrato"])
		{
			if($ccontrato!=0)
			{

				$html .= "<tr><td colspan=\"5\" align=\"right\">";
				$html .= "<table><tr><th>T. Renta</th><th>&nbsp;</td><th>T. Mantenimiento</th><th>&nbsp;</th><th>T. Interes</th><th>&nbsp;</th><th>Total</th></tr>";
				$html .= "<tr><td align=\"center\">$ " . number_format($rentas,2) . "</td><td align=\"center\">+</td><td align=\"center\">$ " . number_format($otros,2) . "</td><td align=\"center\">+</td><td align=\"center\">$ " . number_format($interes,2) . "</td><td align=\"center\">=</td><td align=\"center\"><strong>$ " . number_format(($rentas+$otros+$interes),2) . "</strong></td></tr></table>";
				$html .= "</td></tr>";

				$html .= "</table></td></tr>";
				//pies de datos de las sumas


				//reinicio de las sumas
				$grentas +=$rentas;
				$gotros +=$otros;
				$ginteres +=$interes;
				$rentas=0;
				$otros=0;
				$interes=0;

				//Saltos de lineas
				//echo "<br><br><br><br>";
			}
			
			$Cabeceratabla="<tr><th>Contrato: </th><td colspan=\"2\">" . $row["elidcontrato"]  . " </td></tr>";
			$Cabeceratabla .="<tr><th>Inquilino: </th><td colspan=\"2\">" . $row["nombre"] . " " . $row["nombre2"] . " " . $row["apaterno"] . " " . $row["amaterno"] . "(Tel. " . $row["inqtel"] . ")</td></tr>";
			$Cabeceratabla .="<tr><th>Inmueble: </th><td colspan=\"2\">" .   $row["calle"] . " No." . $row["numeroext"] . " Int." . $row["numeroint"] . " Col." . $row["colonia"] . " Deleg/Mun. ". $row["delmun"] . " C.P. " . $row["cp"]  . " Tel. " . $row["itel"] . " </td></tr>";
			$Cabeceratabla .="<tr><th>Obligado Solidario: </th><td colspan=\"2\">" . $row["fnombre"] . " " . $row["fnombre2"] . " " . $row["fapaterno"] . " " . $row["famaterno"]  . " (Tel. " . $row["ftel"] . ")</td></tr>";
			//echo "\n<tr><td><br><table border=\"1\" width=\"100%\">$Cabeceratabla<tr><th>Contrato</th><th>Nombre</th><th>Fecha nat. pago</th><th>Concepto</th><th>Cantidad</th></tr>\n";
			$html .= "\n<tr><td><br><table border=\"1\" width=\"100%\">$Cabeceratabla<tr><th>Fecha nat. pago</th><th>Concepto</th><th>Cantidad</th></tr>\n";
			$ccontrato=$row["elidcontrato"];
		}


		if (is_null($row["interes"])==false and $row["interes"]==1)
		{

			$concepto = "INT. 10% SOBRE ADEUDO GENERADO EL " . $row["fechagenerado"] . "(" . $row["tipocobro"] . ")";
			$interes += $row["cantidad"] + $row["ivah"];
			$Pagado=$row["cantidad"] + $row["ivah"] ;

		}
		else
		{
			$concepto = $row["tipocobro"];
			if(strtoupper($row["tipocobro"])=="RENTA")
			{
			
				if ($row["aplicado"]==false )
				{
					$rentas +=($row["cantidad"] + $row["ivah"]);
					$Pagado=($row["cantidad"] + $row["ivah"]);
			
				}
				else
				{
					$rentas +=$row["cantidad"] ;
					$Pagado=$row["cantidad"] ;
				}

			
			
				//$rentas +=$row["cantidad"] + $row["ivah"];

			}
			else
			{
				if ($row["aplicado"]==false )
				{
					$otros +=($row["cantidad"] + $row["ivah"]);
					$Pagado=($row["cantidad"] + $row["ivah"]);
			
				}
				else
				{
					$otros +=$row["cantidad"] ;
					$Pagado=$row["cantidad"] ;
				}			
			
			
				//$otros +=$row["cantidad"] + $row["ivah"];
			}


		}


		//echo "<tr><td>" . $row["elidcontrato"] . "</td><td>" . $row["nombre"] . " " . $row["nombre2"] . " " . $row["apaterno"] . " " .$row["amaterno"] . "</td><td>" . $row["fechanaturalpago"] . "</td><td>$concepto</td><td align=\"right\">" . ($row["cantidad"] + $row["iva"]) . "</td></tr>\n";
		$html .= "<tr><td>" . $row["fechanaturalpago"] . "</td><td>$concepto</td><td align=\"right\">$ " . number_format($Pagado,2) . "</td></tr>\n";

	}
	$html .= "<tr><td colspan=\"5\" align=\"right\">";
	$html .= "<table><tr><th>T. Renta</th><th>&nbsp;</td><th>T. Mantenimiento</th><th>&nbsp;</th><th>T. Interes</th><th>&nbsp;</th><th>Total</th></tr>";
	$html .= "<tr><td align=\"center\">$ " . number_format($rentas,2) . "</td><td align=\"center\">+</td><td align=\"center\">$ " . number_format($otros,2) . "</td><td align=\"center\">+</td><td align=\"center\">$ " . number_format($interes,2) . "</td><td align=\"center\">=</td><td align=\"center\"><strong>$ " . number_format(($rentas+$otros+$interes),2) . "</strong></td></tr></table>";
	$html .= "</td></tr>";
	$html .= "</table></td></tr>";
	$html .= "<tr><td align=\"right\"><br>";
/*	echo "<table><tr><th>G. T. Renta</th><th>&nbsp;</td><th>G .T. Mantenimiento</th><th>&nbsp;</th><th>G. T. Interes</th><th>&nbsp;</th><th>Gran Total</th></tr>";
	echo "<tr><td align=\"center\">$ " . number_format($grentas,2) . "</td><td align=\"center\">+</td><td align=\"center\">$ " . number_format($gotros,2) . "</td><td align=\"center\">+</td><td align=\"center\">$ " . number_format($ginteres,2) . "</td><td align=\"center\">=</td><td align=\"center\"><strong>$ " . number_format(($grentas+$gotros+$ginteres),2) . "</strong></td></tr></table>";
	echo "</td></tr>";
	echo "</table>";
*/
	echo CambiaAcentosaHTML($html);

}
else
{

	echo "A&uacute;n no se ha firmado con el servidor";

}
?>
</BODY>
</HTML>